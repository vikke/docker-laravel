<?php

namespace Dotenv\Exception;

interface ExceptionInterface
{
    //
}
